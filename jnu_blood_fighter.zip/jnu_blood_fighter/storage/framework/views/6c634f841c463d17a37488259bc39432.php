

<?php $__env->startSection('title', 'Edit Donor'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card shadow">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0"><i class="bi bi-pencil-square"></i> Edit Donor: <?php echo e($donor->name); ?></h4>
                    <a href="<?php echo e(route('admin.donors')); ?>" class="btn btn-sm btn-light">
                        <i class="bi bi-arrow-left"></i> Back to Donors
                    </a>
                </div>
                <div class="card-body p-4">
                    
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <strong><i class="bi bi-exclamation-triangle-fill"></i> Validation Errors!</strong>
                            <ul class="mb-0 mt-2">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="bi bi-check-circle-fill"></i> <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="bi bi-exclamation-circle-fill"></i> <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('admin.donors.update', $donor->id)); ?>">
                        <?php echo csrf_field(); ?>
                        
                        
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="bi bi-person-fill"></i> Personal Information</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Full Name <span class="text-danger">*</span></label>
                                        <input 
                                            type="text" 
                                            name="name" 
                                            class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            value="<?php echo e(old('name', $donor->name)); ?>" 
                                            required
                                            maxlength="255"
                                        >
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Email</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="bi bi-envelope-fill"></i></span>
                                            <input type="email" class="form-control bg-light" value="<?php echo e($donor->email); ?>" disabled>
                                        </div>
                                        <small class="text-muted"><i class="bi bi-lock-fill"></i> Email cannot be changed</small>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Phone Number <span class="text-danger">*</span></label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="bi bi-telephone-fill"></i></span>
                                            <input 
                                                type="text" 
                                                name="phone" 
                                                class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                value="<?php echo e(old('phone', $donor->phone)); ?>" 
                                                required
                                                maxlength="11"
                                                pattern="01[0-9]{9}"
                                                placeholder="01XXXXXXXXX"
                                            >
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php else: ?>
                                            <small class="text-muted">Format: 01XXXXXXXXX (11 digits)</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Blood Type <span class="text-danger">*</span></label>
                                        <select name="blood_type" class="form-select <?php $__errorArgs = ['blood_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <?php $__currentLoopData = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type); ?>" <?php echo e(old('blood_type', $donor->blood_type) == $type ? 'selected' : ''); ?>>
                                                    <?php echo e($type); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['blood_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="bi bi-geo-alt-fill"></i> Location Information</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label"><strong>Division</strong></label>
                                            <div class="p-2 bg-light rounded">
                                                <i class="bi bi-pin-map-fill text-primary"></i> <?php echo e($donor->division); ?>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label"><strong>District</strong></label>
                                            <div class="p-2 bg-light rounded">
                                                <i class="bi bi-pin-fill text-primary"></i> <?php echo e($donor->district); ?>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label"><strong>Upazila</strong></label>
                                            <div class="p-2 bg-light rounded">
                                                <i class="bi bi-geo-fill text-primary"></i> <?php echo e($donor->upazila); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="alert alert-info mb-0">
                                    <i class="bi bi-info-circle-fill"></i> <strong>Note:</strong> Location details (Division, District, Upazila) cannot be changed from the admin panel for security reasons.
                                </div>
                            </div>
                        </div>

                        
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="bi bi-house-fill"></i> Address Details</h6>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="form-label">Detailed Address</label>
                                    <textarea class="form-control bg-light" rows="3" disabled><?php echo e($donor->address); ?></textarea>
                                    <small class="text-muted"><i class="bi bi-lock-fill"></i> Address cannot be changed from admin panel</small>
                                </div>
                            </div>
                        </div>

                        
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="bi bi-droplet-fill"></i> Donation Status</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Last Donation Date</label>
                                        <input 
                                            type="date" 
                                            name="last_donation_date" 
                                            class="form-control <?php $__errorArgs = ['last_donation_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            value="<?php echo e(old('last_donation_date', $donor->last_donation_date?->format('Y-m-d'))); ?>"
                                            max="<?php echo e(date('Y-m-d')); ?>"
                                        >
                                        <?php $__errorArgs = ['last_donation_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php else: ?>
                                            <small class="text-muted">Leave empty if never donated before</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Availability Status</label>
                                        <div class="form-check form-switch mt-2" style="font-size: 1.1rem;">
                                            <input 
                                                class="form-check-input" 
                                                type="checkbox" 
                                                name="is_available" 
                                                id="is_available" 
                                                value="1" 
                                                <?php echo e(old('is_available', $donor->is_available) ? 'checked' : ''); ?>

                                                style="width: 3em; height: 1.5em;"
                                            >
                                            <label class="form-check-label ms-2" for="is_available">
                                                <strong>Available to donate blood</strong>
                                            </label>
                                        </div>
                                        <?php if($donor->last_donation_date): ?>
                                            <?php if($donor->canDonate()): ?>
                                                <div class="alert alert-success mt-2 mb-0 py-2">
                                                    <i class="bi bi-check-circle-fill"></i> <strong>Eligible to donate now</strong><br>
                                                    <small>Last donation was <?php echo e($donor->last_donation_date->diffForHumans()); ?></small>
                                                </div>
                                            <?php else: ?>
                                                <div class="alert alert-warning mt-2 mb-0 py-2">
                                                    <i class="bi bi-exclamation-triangle-fill"></i> <strong>Must wait 3 months</strong><br>
                                                    <small>Last donation: <?php echo e($donor->last_donation_date->format('M d, Y')); ?></small>
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <div class="alert alert-info mt-2 mb-0 py-2">
                                                <i class="bi bi-info-circle-fill"></i> <strong>Never donated before</strong><br>
                                                <small>This donor is eligible to donate</small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="bi bi-clock-history"></i> System Information</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="p-3 bg-light rounded">
                                            <strong><i class="bi bi-calendar-plus"></i> Registered:</strong><br>
                                            <?php echo e($donor->created_at->format('M d, Y h:i A')); ?><br>
                                            <small class="text-muted"><?php echo e($donor->created_at->diffForHumans()); ?></small>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="p-3 bg-light rounded">
                                            <strong><i class="bi bi-pencil-square"></i> Last Updated:</strong><br>
                                            <?php echo e($donor->updated_at->format('M d, Y h:i A')); ?><br>
                                            <small class="text-muted"><?php echo e($donor->updated_at->diffForHumans()); ?></small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary btn-lg flex-fill">
                                <i class="bi bi-save"></i> Update Donor Information
                            </button>
                            <a href="<?php echo e(route('admin.donors')); ?>" class="btn btn-secondary btn-lg">
                                <i class="bi bi-x-lg"></i> Cancel
                            </a>
                            <button type="button" class="btn btn-outline-danger btn-lg" onclick="if(confirm('Are you sure you want to delete this donor? This action cannot be undone.')) { document.getElementById('delete-form').submit(); }">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                        </div>
                    </form>

                    
                    <form id="delete-form" method="POST" action="<?php echo e(route('admin.donors.delete', $donor->id)); ?>" class="d-none">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Phone number formatting
    const phoneInput = document.querySelector('input[name="phone"]');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            // Remove non-numeric characters
            this.value = this.value.replace(/[^0-9]/g, '');
            
            // Limit to 11 digits
            if (this.value.length > 11) {
                this.value = this.value.slice(0, 11);
            }
        });
    }

    // Availability toggle feedback
    const availabilitySwitch = document.getElementById('is_available');
    if (availabilitySwitch) {
        availabilitySwitch.addEventListener('change', function() {
            const label = this.nextElementSibling;
            if (this.checked) {
                label.innerHTML = '<strong class="text-success">Available to donate blood</strong>';
            } else {
                label.innerHTML = '<strong class="text-danger">Not available to donate blood</strong>';
            }
        });
    }

    // Form submission confirmation
    const form = document.querySelector('form[action*="update"]');
    if (form) {
        form.addEventListener('submit', function(e) {
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Updating...';
        });
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\tusha\OneDrive\Desktop\blood donor minimal\jnu_blood_fighter\resources\views\admin\edit-donor.blade.php ENDPATH**/ ?>