

<?php $__env->startSection('title', 'Post Blood Request'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card shadow">
                <div class="card-header bg-danger text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="mb-0"><i class="bi bi-plus-circle-fill"></i> Post Blood Request</h4>
                        <a href="<?php echo e(route('donor.dashboard')); ?>" class="btn btn-sm btn-light">
                            <i class="bi bi-arrow-left"></i> Back to Dashboard
                        </a>
                    </div>
                </div>
                <div class="card-body p-4">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <strong><i class="bi bi-exclamation-triangle-fill"></i> Please fix the following errors:</strong>
                            <ul class="mb-0 mt-2">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('blood-request.store')); ?>" id="requestForm">
                        <?php echo csrf_field(); ?>

                        <!-- Patient Information -->
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="bi bi-person-fill"></i> Patient Information</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Patient Name <span class="text-danger">*</span></label>
                                        <input type="text" name="patient_name" class="form-control <?php $__errorArgs = ['patient_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               value="<?php echo e(old('patient_name')); ?>" required maxlength="255" placeholder="Enter patient's full name">
                                        <?php $__errorArgs = ['patient_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Disease/Reason <span class="text-danger">*</span></label>
                                        <input type="text" name="disease" class="form-control <?php $__errorArgs = ['disease'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               value="<?php echo e(old('disease')); ?>" required maxlength="255" placeholder="e.g., Surgery, Accident, Thalassemia">
                                        <?php $__errorArgs = ['disease'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Blood Requirements -->
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="bi bi-droplet-fill"></i> Blood Requirements</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Blood Type <span class="text-danger">*</span></label>
                                        <select name="blood_type" class="form-select <?php $__errorArgs = ['blood_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">-- Select Blood Type --</option>
                                            <?php $__currentLoopData = $bloodTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type); ?>" <?php echo e(old('blood_type') == $type ? 'selected' : ''); ?>><?php echo e($type); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['blood_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Blood Quantity (Bags) <span class="text-danger">*</span></label>
                                        <input type="number" name="blood_quantity" class="form-control <?php $__errorArgs = ['blood_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               value="<?php echo e(old('blood_quantity', 1)); ?>" required min="1" max="10">
                                        <?php $__errorArgs = ['blood_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <small class="text-muted">1 bag = 450ml approx.</small>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">When Needed? <span class="text-danger">*</span></label>
                                        <div class="form-check form-switch mb-2" style="font-size: 1.1rem;">
                                            <input class="form-check-input" type="checkbox" name="is_emergency" id="is_emergency" 
                                                   value="1" <?php echo e(old('is_emergency') ? 'checked' : ''); ?> style="width: 3em; height: 1.5em;">
                                            <label class="form-check-label ms-2 text-danger fw-bold" for="is_emergency">
                                                <i class="bi bi-exclamation-triangle-fill"></i> EMERGENCY (Needed Immediately)
                                            </label>
                                        </div>
                                        <input type="datetime-local" name="needed_date" id="needed_date" 
                                               class="form-control <?php $__errorArgs = ['needed_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               value="<?php echo e(old('needed_date')); ?>" min="<?php echo e(date('Y-m-d\TH:i')); ?>">
                                        <?php $__errorArgs = ['needed_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <small class="text-muted" id="date-hint">Or select date & time above</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Hospital Location -->
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="bi bi-hospital-fill"></i> Hospital Information</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Hospital Name <span class="text-danger">*</span></label>
                                        <input type="text" name="hospital_name" class="form-control <?php $__errorArgs = ['hospital_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               value="<?php echo e(old('hospital_name')); ?>" required maxlength="255" placeholder="Enter hospital name">
                                        <?php $__errorArgs = ['hospital_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Hospital Address <span class="text-danger">*</span></label>
                                        <input type="text" name="hospital_location" class="form-control <?php $__errorArgs = ['hospital_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               value="<?php echo e(old('hospital_location')); ?>" required maxlength="500" placeholder="Full hospital address">
                                        <?php $__errorArgs = ['hospital_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Division <span class="text-danger">*</span></label>
                                        <select name="division" id="division" class="form-select <?php $__errorArgs = ['division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">-- Select Division --</option>
                                            <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $div): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($div['en']); ?>" <?php echo e(old('division') == $div['en'] ? 'selected' : ''); ?>><?php echo e($div['en']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">District <span class="text-danger">*</span></label>
                                        <select name="district" id="district" class="form-select <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">-- Select District --</option>
                                        </select>
                                        <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Upazila <span class="text-danger">*</span></label>
                                        <select name="upazila" id="upazila" class="form-select <?php $__errorArgs = ['upazila'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="">-- Select Upazila --</option>
                                        </select>
                                        <?php $__errorArgs = ['upazila'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Contact Information -->
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="bi bi-telephone-fill"></i> Contact Information</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Contact Number <span class="text-danger">*</span></label>
                                        <input type="text" name="contact_number" class="form-control <?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               value="<?php echo e(old('contact_number', $donor->phone)); ?>" required maxlength="11" 
                                               pattern="01[0-9]{9}" placeholder="01XXXXXXXXX">
                                        <?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <small class="text-muted">This number will be shown to potential donors</small>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Additional Notes (Optional)</label>
                                        <textarea name="additional_notes" class="form-control" rows="3" maxlength="1000" 
                                                  placeholder="Any additional information that might be helpful..."><?php echo e(old('additional_notes')); ?></textarea>
                                        <small class="text-muted">Max 1000 characters</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-danger btn-lg flex-fill" id="submitBtn">
                                <i class="bi bi-megaphone-fill"></i> Post Blood Request
                            </button>
                            <a href="<?php echo e(route('donor.dashboard')); ?>" class="btn btn-secondary btn-lg">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const oldDivision = '<?php echo e(old('division')); ?>';
    const oldDistrict = '<?php echo e(old('district')); ?>';
    const oldUpazila = '<?php echo e(old('upazila')); ?>';
    
    const divisionSelect = document.getElementById('division');
    const districtSelect = document.getElementById('district');
    const upazilaSelect = document.getElementById('upazila');
    const emergencyCheckbox = document.getElementById('is_emergency');
    const neededDateInput = document.getElementById('needed_date');
    const dateHint = document.getElementById('date-hint');

    // Emergency checkbox handler
    emergencyCheckbox.addEventListener('change', function() {
        if (this.checked) {
            neededDateInput.disabled = true;
            neededDateInput.required = false;
            neededDateInput.value = '';
            dateHint.textContent = 'Blood needed immediately';
            dateHint.classList.add('text-danger', 'fw-bold');
        } else {
            neededDateInput.disabled = false;
            neededDateInput.required = true;
            dateHint.textContent = 'Select when blood is needed';
            dateHint.classList.remove('text-danger', 'fw-bold');
        }
    });

    // Trigger on load if emergency was checked
    if (emergencyCheckbox.checked) {
        emergencyCheckbox.dispatchEvent(new Event('change'));
    }

    // Location dropdowns
    divisionSelect.addEventListener('change', function() {
        loadDistricts(this.value);
    });

    districtSelect.addEventListener('change', function() {
        loadUpazilas(this.value);
    });

    function loadDistricts(division) {
        districtSelect.innerHTML = '<option value="">-- Select District --</option>';
        upazilaSelect.innerHTML = '<option value="">-- Select Upazila --</option>';
        
        if (division) {
            fetch(`/api/districts/${encodeURIComponent(division)}`)
                .then(response => response.json())
                .then(data => {
                    data.forEach(district => {
                        const option = new Option(district, district, false, district === oldDistrict);
                        districtSelect.add(option);
                    });
                    if (oldDistrict && divisionSelect.value === oldDivision) {
                        districtSelect.value = oldDistrict;
                        districtSelect.dispatchEvent(new Event('change'));
                    }
                });
        }
    }

    function loadUpazilas(district) {
        upazilaSelect.innerHTML = '<option value="">-- Select Upazila --</option>';
        
        if (district) {
            fetch(`/api/upazilas/${encodeURIComponent(district)}`)
                .then(response => response.json())
                .then(data => {
                    data.forEach(upazila => {
                        const option = new Option(upazila, upazila, false, upazila === oldUpazila);
                        upazilaSelect.add(option);
                    });
                    if (oldUpazila && districtSelect.value === oldDistrict) {
                        upazilaSelect.value = oldUpazila;
                    }
                });
        }
    }

    // Initialize on page load
    if (oldDivision) {
        loadDistricts(oldDivision);
    }

    // Phone number formatting
    document.querySelector('input[name="contact_number"]').addEventListener('input', function(e) {
        this.value = this.value.replace(/[^0-9]/g, '').slice(0, 11);
    });

    // Form submission
    document.getElementById('requestForm').addEventListener('submit', function() {
        const submitBtn = document.getElementById('submitBtn');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Posting Request...';
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\tusha\OneDrive\Desktop\blood donor minimal\jnu_blood_fighter\resources\views/donor/create-request.blade.php ENDPATH**/ ?>