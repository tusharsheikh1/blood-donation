

<?php $__env->startSection('title', 'My Blood Requests'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="bi bi-clipboard-check-fill"></i> My Blood Requests</h2>
        <div>
            <a href="<?php echo e(route('blood-request.create')); ?>" class="btn btn-danger me-2">
                <i class="bi bi-plus-circle-fill"></i> New Request
            </a>
            <a href="<?php echo e(route('donor.dashboard')); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle-fill"></i> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle-fill"></i> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3 shadow-sm <?php echo e($request->status === 'active' ? ($request->is_emergency ? 'border-danger border-2' : '') : 'bg-light'); ?>">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-2 text-center">
                        <div class="blood-icon-large mb-2"><?php echo e($request->blood_type); ?></div>
                        <span class="badge bg-secondary"><?php echo e($request->blood_quantity); ?> bag(s)</span>
                        <br>
                        <?php if($request->status === 'active'): ?>
                            <span class="badge bg-success mt-2">Active</span>
                        <?php elseif($request->status === 'fulfilled'): ?>
                            <span class="badge bg-info mt-2">Fulfilled</span>
                        <?php else: ?>
                            <span class="badge bg-secondary mt-2">Cancelled</span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-7">
                        <h5 class="mb-2">
                            <?php echo e($request->patient_name); ?>

                            <?php if($request->is_emergency): ?>
                                <span class="badge bg-danger"><i class="bi bi-exclamation-triangle-fill"></i> EMERGENCY</span>
                            <?php elseif($request->isUrgent()): ?>
                                <span class="badge bg-warning text-dark"><i class="bi bi-clock-fill"></i> URGENT</span>
                            <?php endif; ?>
                        </h5>
                        <p class="mb-1"><strong>Disease:</strong> <?php echo e($request->disease); ?></p>
                        <p class="mb-1"><strong>Hospital:</strong> <?php echo e($request->hospital_name); ?></p>
                        <p class="mb-1"><strong>Location:</strong> <?php echo e($request->hospital_location); ?>, <?php echo e($request->upazila); ?>, <?php echo e($request->district); ?></p>
                        <?php if(!$request->is_emergency && $request->needed_date): ?>
                            <p class="mb-1"><strong>Needed:</strong> <?php echo e($request->needed_date->format('M d, Y h:i A')); ?></p>
                        <?php endif; ?>
                        <p class="mb-1"><strong>Contact:</strong> <?php echo e($request->contact_number); ?></p>
                        <?php if($request->additional_notes): ?>
                            <p class="mb-1 small text-muted"><strong>Notes:</strong> <?php echo e($request->additional_notes); ?></p>
                        <?php endif; ?>
                        <p class="mb-0 small text-muted">Posted <?php echo e($request->created_at->diffForHumans()); ?></p>
                    </div>
                    <div class="col-md-3 text-end">
                        <?php if($request->status === 'active'): ?>
                            <div class="btn-group-vertical w-100 gap-2">
                                <form method="POST" action="<?php echo e(route('blood-request.update-status', $request->id)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="status" value="fulfilled">
                                    <button type="submit" class="btn btn-success w-100" onclick="return confirm('Mark this request as fulfilled?')">
                                        <i class="bi bi-check-circle-fill"></i> Mark Fulfilled
                                    </button>
                                </form>
                                <form method="POST" action="<?php echo e(route('blood-request.update-status', $request->id)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="status" value="cancelled">
                                    <button type="submit" class="btn btn-warning w-100" onclick="return confirm('Cancel this request?')">
                                        <i class="bi bi-x-circle-fill"></i> Cancel
                                    </button>
                                </form>
                            </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('blood-request.destroy', $request->id)); ?>" class="d-inline mt-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-outline-danger w-100" onclick="return confirm('Delete this request permanently?')">
                                <i class="bi bi-trash-fill"></i> Delete
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card shadow-sm">
            <div class="card-body text-center py-5">
                <i class="bi bi-inbox display-1 text-muted mb-3"></i>
                <h5 class="text-muted">No Blood Requests Yet</h5>
                <p class="text-muted mb-3">You haven't posted any blood requests.</p>
                <a href="<?php echo e(route('blood-request.create')); ?>" class="btn btn-danger">
                    <i class="bi bi-plus-circle-fill"></i> Create Your First Request
                </a>
            </div>
        </div>
    <?php endif; ?>

    <?php if($requests->hasPages()): ?>
        <div class="mt-4">
            <?php echo e($requests->links()); ?>

        </div>
    <?php endif; ?>
</div>

<style>
.blood-icon-large {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    font-weight: bold;
    margin: 0 auto;
    box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3);
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\tusha\OneDrive\Desktop\blood donor minimal\jnu_blood_fighter\resources\views\donor\my-requests.blade.php ENDPATH**/ ?>