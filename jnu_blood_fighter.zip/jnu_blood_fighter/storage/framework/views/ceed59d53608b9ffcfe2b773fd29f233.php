

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle-fill"></i> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle-fill"></i> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <h2 class="mb-4">Admin Dashboard</h2>

    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-white bg-danger shadow">
                <div class="card-body text-center">
                    <h5 class="card-title">Total Donors</h5>
                    <h2 class="display-4"><?php echo e($stats['total_donors']); ?></h2>
                    <p class="mb-0"><i class="bi bi-people-fill"></i> Registered</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-success shadow">
                <div class="card-body text-center">
                    <h5 class="card-title">Available Donors</h5>
                    <h2 class="display-4"><?php echo e($stats['available_donors']); ?></h2>
                    <p class="mb-0"><i class="bi bi-check-circle-fill"></i> Ready to donate</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-info shadow">
                <div class="card-body text-center">
                    <h5 class="card-title">Blood Types</h5>
                    <h2 class="display-4"><?php echo e($stats['by_blood_type']->count()); ?></h2>
                    <p class="mb-0"><i class="bi bi-droplet-fill"></i> Types available</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning shadow">
                <div class="card-body text-center">
                    <h5 class="card-title">Divisions</h5>
                    <h2 class="display-4"><?php echo e($stats['by_division']->count()); ?></h2>
                    <p class="mb-0"><i class="bi bi-geo-alt-fill"></i> Locations</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-light">
                    <h5 class="mb-0"><i class="bi bi-droplet-fill"></i> Donors by Blood Type</h5>
                </div>
                <div class="card-body">
                    <?php if($stats['total_donors'] > 0): ?>
                        <table class="table table-sm table-hover">
                            <thead>
                                <tr>
                                    <th>Blood Type</th>
                                    <th class="text-end">Count</th>
                                    <th class="text-end">Percentage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $stats['by_blood_type']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="badge bg-danger"><?php echo e($stat->blood_type); ?></span></td>
                                        <td class="text-end"><?php echo e($stat->count); ?></td>
                                        <td class="text-end"><?php echo e(round(($stat->count / $stats['total_donors']) * 100, 1)); ?>%</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle"></i> No donors registered yet.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-light">
                    <h5 class="mb-0"><i class="bi bi-geo-alt-fill"></i> Donors by Division</h5>
                </div>
                <div class="card-body">
                    <?php if($stats['total_donors'] > 0): ?>
                        <table class="table table-sm table-hover">
                            <thead>
                                <tr>
                                    <th>Division</th>
                                    <th class="text-end">Donors</th>
                                    <th class="text-end">Percentage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $stats['by_division']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($stat->division); ?></td>
                                        <td class="text-end"><?php echo e($stat->count); ?></td>
                                        <td class="text-end"><?php echo e(round(($stat->count / $stats['total_donors']) * 100, 1)); ?>%</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle"></i> No donors registered yet.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="bi bi-clock-history"></i> Recent Donors</h5>
            <a href="<?php echo e(route('admin.donors')); ?>" class="btn btn-sm btn-primary">
                <i class="bi bi-list"></i> View All Donors
            </a>
        </div>
        <div class="card-body">
            <?php if($stats['recent_donors']->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Blood Type</th>
                                <th>Division</th>
                                <th>District</th>
                                <th>Upazila</th>
                                <th>Contact</th>
                                <th>Status</th>
                                <th>Registered</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $stats['recent_donors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($donor->name); ?></td>
                                    <td><span class="badge bg-danger"><?php echo e($donor->blood_type); ?></span></td>
                                    <td><?php echo e($donor->division); ?></td>
                                    <td><?php echo e($donor->district); ?></td>
                                    <td><?php echo e($donor->upazila); ?></td>
                                    <td><a href="tel:<?php echo e($donor->phone); ?>"><?php echo e($donor->phone); ?></a></td>
                                    <td>
                                        <?php if($donor->is_available): ?>
                                            <span class="badge bg-success">Available</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Unavailable</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($donor->created_at->diffForHumans()); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info mb-0">
                    <i class="bi bi-info-circle"></i> No donors registered yet. <a href="<?php echo e(route('donor.register')); ?>">Register the first donor</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\tusha\OneDrive\Desktop\blood donor minimal\jnu_blood_fighter\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>