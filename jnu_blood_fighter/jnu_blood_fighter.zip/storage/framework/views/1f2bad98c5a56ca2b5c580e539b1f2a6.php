

<?php $__env->startSection('title', 'Edit Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Edit Your Profile</h4>
                </div>
                <div class="card-body p-4">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('donor.profile.update')); ?>" id="profileForm">
                        <?php echo csrf_field(); ?>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Full Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $donor->name)); ?>" required>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone Number <span class="text-danger">*</span></label>
                                <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone', $donor->phone)); ?>" placeholder="01XXXXXXXXX" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Blood Type <span class="text-danger">*</span></label>
                                <select name="blood_type" class="form-select" required>
                                    <?php $__currentLoopData = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type); ?>" <?php echo e(old('blood_type', $donor->blood_type) == $type ? 'selected' : ''); ?>><?php echo e($type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label">Last Donation Date</label>
                                <input type="date" name="last_donation_date" class="form-control" value="<?php echo e(old('last_donation_date', $donor->last_donation_date?->format('Y-m-d'))); ?>">
                                <small class="text-muted">Leave empty if never donated</small>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Division <span class="text-danger">*</span></label>
                                <select name="division" id="division" class="form-select" required>
                                    <option value="">Select Division</option>
                                    <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $div): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($div['en']); ?>" <?php echo e(old('division', $donor->division) == $div['en'] ? 'selected' : ''); ?>>
                                            <?php echo e($div['en']); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label">District <span class="text-danger">*</span></label>
                                <select name="district" id="district" class="form-select" required>
                                    <option value="">Select District</option>
                                </select>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label">Upazila <span class="text-danger">*</span></label>
                                <select name="upazila" id="upazila" class="form-select" required>
                                    <option value="">Select Upazila</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Address <span class="text-danger">*</span></label>
                            <textarea name="address" class="form-control" rows="2" required><?php echo e(old('address', $donor->address)); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="is_available" id="is_available" value="1" <?php echo e(old('is_available', $donor->is_available) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="is_available">
                                    I am available to donate blood
                                </label>
                            </div>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary flex-fill">Update Profile</button>
                            <a href="<?php echo e(route('donor.dashboard')); ?>" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
const oldDistrict = '<?php echo e(old('district', $donor->district)); ?>';
const oldUpazila = '<?php echo e(old('upazila', $donor->upazila)); ?>';

document.getElementById('division').addEventListener('change', function() {
    loadDistricts(this.value);
});

document.getElementById('district').addEventListener('change', function() {
    loadUpazilas(this.value);
});

function loadDistricts(division) {
    const districtSelect = document.getElementById('district');
    const upazilaSelect = document.getElementById('upazila');
    
    districtSelect.innerHTML = '<option value="">Select District</option>';
    upazilaSelect.innerHTML = '<option value="">Select Upazila</option>';
    
    if (division) {
        fetch(`/api/districts/${division}`)
            .then(response => response.json())
            .then(data => {
                data.forEach(district => {
                    const option = new Option(district, district, false, district === oldDistrict);
                    districtSelect.add(option);
                });
                if (oldDistrict) {
                    districtSelect.value = oldDistrict;
                    loadUpazilas(oldDistrict);
                }
            });
    }
}

function loadUpazilas(district) {
    const upazilaSelect = document.getElementById('upazila');
    upazilaSelect.innerHTML = '<option value="">Select Upazila</option>';
    
    if (district) {
        fetch(`/api/upazilas/${district}`)
            .then(response => response.json())
            .then(data => {
                data.forEach(upazila => {
                    const option = new Option(upazila, upazila, false, upazila === oldUpazila);
                    upazilaSelect.add(option);
                });
                if (oldUpazila) {
                    upazilaSelect.value = oldUpazila;
                }
            });
    }
}

// Load on page load
const currentDivision = document.getElementById('division').value;
if (currentDivision) {
    loadDistricts(currentDivision);
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\tusha\OneDrive\Desktop\blood donor minimal\jnu_blood_fighter\resources\views/donor/profile.blade.php ENDPATH**/ ?>