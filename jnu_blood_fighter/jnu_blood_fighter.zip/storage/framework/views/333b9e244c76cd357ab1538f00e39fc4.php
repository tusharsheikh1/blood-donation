

<?php $__env->startSection('title', 'Manage Donors'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle-fill"></i> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle-fill"></i> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="bi bi-people-fill"></i> Manage Donors</h2>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Back to Dashboard
        </a>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h6 class="mb-3"><i class="bi bi-funnel"></i> Filter Donors</h6>
            <form method="GET" action="<?php echo e(route('admin.donors')); ?>">
                <div class="row g-3">
                    <div class="col-md-4">
                        <input 
                            type="text" 
                            name="search" 
                            class="form-control" 
                            placeholder="Search by name, email, or phone" 
                            value="<?php echo e(request('search')); ?>"
                        >
                    </div>
                    <div class="col-md-2">
                        <select name="blood_type" class="form-select">
                            <option value="">All Blood Types</option>
                            <?php $__currentLoopData = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type); ?>" <?php echo e(request('blood_type') == $type ? 'selected' : ''); ?>>
                                    <?php echo e($type); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="division" class="form-select">
                            <option value="">All Divisions</option>
                            <?php $__currentLoopData = ['Dhaka', 'Chattogram', 'Rajshahi', 'Khulna', 'Barishal', 'Sylhet', 'Rangpur', 'Mymensingh']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($division); ?>" <?php echo e(request('division') == $division ? 'selected' : ''); ?>>
                                    <?php echo e($division); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary flex-fill">
                                <i class="bi bi-search"></i> Search
                            </button>
                            <a href="<?php echo e(route('admin.donors')); ?>" class="btn btn-secondary" title="Clear filters">
                                <i class="bi bi-x-lg"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
            <h5 class="mb-0">All Donors (<?php echo e($donors->total()); ?>)</h5>
            <?php if(request()->hasAny(['search', 'blood_type', 'division'])): ?>
                <span class="badge bg-info">
                    <i class="bi bi-funnel-fill"></i> Filters Active
                </span>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Blood</th>
                            <th>Location</th>
                            <th>Status</th>
                            <th>Last Donation</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $donors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($donor->id); ?></td>
                                <td><?php echo e($donor->name); ?></td>
                                <td><a href="mailto:<?php echo e($donor->email); ?>"><?php echo e($donor->email); ?></a></td>
                                <td><a href="tel:<?php echo e($donor->phone); ?>"><?php echo e($donor->phone); ?></a></td>
                                <td><span class="badge bg-danger"><?php echo e($donor->blood_type); ?></span></td>
                                <td>
                                    <small>
                                        <?php echo e($donor->upazila); ?><br>
                                        <?php echo e($donor->district); ?>, <?php echo e($donor->division); ?>

                                    </small>
                                </td>
                                <td>
                                    <?php if($donor->is_available): ?>
                                        <span class="badge bg-success">Available</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Unavailable</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($donor->last_donation_date): ?>
                                        <small><?php echo e($donor->last_donation_date->format('M d, Y')); ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">Never</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('admin.donors.edit', $donor->id)); ?>" class="btn btn-outline-primary" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <form method="POST" action="<?php echo e(route('admin.donors.delete', $donor->id)); ?>" class="d-inline" onsubmit="return confirm('Are you sure you want to delete <?php echo e($donor->name); ?>? This action cannot be undone.')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-outline-danger" title="Delete">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center py-4">
                                    <i class="bi bi-inbox display-4 text-muted d-block mb-2"></i>
                                    <p class="text-muted mb-0">
                                        <?php if(request()->hasAny(['search', 'blood_type', 'division'])): ?>
                                            No donors found matching your criteria. <a href="<?php echo e(route('admin.donors')); ?>">Clear filters</a>
                                        <?php else: ?>
                                            No donors registered yet.
                                        <?php endif; ?>
                                    </p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($donors->hasPages()): ?>
                <div class="mt-4">
                    <?php echo e($donors->appends(request()->query())->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\tusha\OneDrive\Desktop\blood donor minimal\jnu_blood_fighter\resources\views/admin/donors.blade.php ENDPATH**/ ?>