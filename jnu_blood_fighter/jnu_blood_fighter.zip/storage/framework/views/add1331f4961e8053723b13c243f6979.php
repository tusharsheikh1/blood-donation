

<?php $__env->startSection('title', 'Donor Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill"></i> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12 mb-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h4 class="mb-0">Welcome, <?php echo e($donor->name); ?>!</h4>
                            <p class="text-muted mb-0">Blood Type: <span class="badge bg-danger"><?php echo e($donor->blood_type); ?></span></p>
                        </div>
                        <div>
                            <a href="<?php echo e(route('donor.profile')); ?>" class="btn btn-primary me-2">
                                <i class="bi bi-pencil-fill"></i> Edit Profile
                            </a>
                            <a href="<?php echo e(route('blood-request.create')); ?>" class="btn btn-danger">
                                <i class="bi bi-megaphone-fill"></i> Request Blood
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card text-white bg-danger shadow-sm">
                <div class="card-body text-center">
                    <h5 class="card-title">Availability Status</h5>
                    <h2><?php echo e($donor->is_available ? 'Available' : 'Not Available'); ?></h2>
                    <p class="mb-0">
                        <?php if($donor->is_available): ?>
                            <i class="bi bi-check-circle"></i> Ready to donate
                        <?php else: ?>
                            <i class="bi bi-x-circle"></i> Currently unavailable
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card text-white bg-info shadow-sm">
                <div class="card-body text-center">
                    <h5 class="card-title">Last Donation</h5>
                    <h2>
                        <?php if($donor->last_donation_date): ?>
                            <?php echo e($donor->last_donation_date->format('M d, Y')); ?>

                        <?php else: ?>
                            Never
                        <?php endif; ?>
                    </h2>
                    <p class="mb-0">
                        <?php if($donor->last_donation_date): ?>
                            <?php echo e($donor->last_donation_date->diffForHumans()); ?>

                        <?php else: ?>
                            No donation record
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card text-white bg-success shadow-sm">
                <div class="card-body text-center">
                    <h5 class="card-title">Can Donate?</h5>
                    <h2><?php echo e($donor->canDonate() ? 'Yes' : 'Not Yet'); ?></h2>
                    <p class="mb-0">
                        <?php if($donor->canDonate()): ?>
                            You are eligible to donate
                        <?php else: ?>
                            Wait 3 months after last donation
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Personal Information</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th width="40%">Email:</th>
                            <td><?php echo e($donor->email); ?></td>
                        </tr>
                        <tr>
                            <th>Phone:</th>
                            <td><?php echo e($donor->phone); ?></td>
                        </tr>
                        <tr>
                            <th>Blood Type:</th>
                            <td><span class="badge bg-danger"><?php echo e($donor->blood_type); ?></span></td>
                        </tr>
                        <tr>
                            <th>Member Since:</th>
                            <td><?php echo e($donor->created_at->format('M d, Y')); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Location</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th width="40%">Division:</th>
                            <td><?php echo e($donor->division); ?></td>
                        </tr>
                        <tr>
                            <th>District:</th>
                            <td><?php echo e($donor->district); ?></td>
                        </tr>
                        <tr>
                            <th>Upazila:</th>
                            <td><?php echo e($donor->upazila); ?></td>
                        </tr>
                        <tr>
                            <th>Address:</th>
                            <td><?php echo e($donor->address); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-light">
            <h5 class="mb-0">Quick Actions</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-primary w-100">
                        <i class="bi bi-search"></i> Find Other Donors
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="<?php echo e(route('blood-request.create')); ?>" class="btn btn-outline-danger w-100">
                        <i class="bi bi-megaphone-fill"></i> Request Blood
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="<?php echo e(route('blood-request.my-requests')); ?>" class="btn btn-outline-info w-100">
                        <i class="bi bi-clipboard-check-fill"></i> My Requests
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="<?php echo e(route('donor.profile')); ?>" class="btn btn-outline-success w-100">
                        <i class="bi bi-pencil"></i> Update Profile
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <form method="POST" action="<?php echo e(route('donor.logout')); ?>" class="d-inline w-100">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-danger w-100">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\tusha\OneDrive\Desktop\blood donor minimal\jnu_blood_fighter\resources\views\donor\dashboard.blade.php ENDPATH**/ ?>